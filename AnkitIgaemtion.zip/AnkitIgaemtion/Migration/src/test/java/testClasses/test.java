package testClasses;

public class test {
	public static void main(String[] args){
		String aa="C:/Eclips/Migration/OutputFiles/CITI_BANK_Migration_Regression_Single_Joint_2018_05_09_12_41_09/FileNameJoint/691699700/691699700_MISMO_2X_Request_Request.xml";
		String split = aa.split("/")[aa.split("/").length-1];
		System.out.println(split);
	}
}
