package primary;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import base.Logging;

public class CallingCITI2X {

	public static void main(String[] args) {
		Long startTime=TimeUnit.MILLISECONDS.toMinutes(System.currentTimeMillis());

		Long endTime;
		try {
			Logging.logger
					.info("Execution Starts at : " + new SimpleDateFormat("YYYY-MM-dd HH:mm:ss").format(new Date()));
			CallingWithOutspace.Scenario1();
			CallingWith1XSpace.Scenario2();
			CallingWith2XSpace.Scenario3();
			CallingWithAllSpace.Scenario4();
		} finally {
			endTime=TimeUnit.MILLISECONDS.toMinutes(System.currentTimeMillis());
			Logging.logger
					.info("Execution Ends at : " + new SimpleDateFormat("YYYY-MM-dd hh:mm:ss").format(new Date())+" And took total \""+ (endTime-startTime) +"\" Minutes");
		}
	}
}