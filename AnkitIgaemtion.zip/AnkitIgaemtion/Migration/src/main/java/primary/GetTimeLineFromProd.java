package primary;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class GetTimeLineFromProd {
	public static void main(String[] args) {		
		//C:\\RemotePerformanceScripts\\1_july_24_July_Prod.xlsx
		
		FileInputStream productname = null;

		try {
			productname = new FileInputStream("C:\\RemotePerformanceScripts\\export_juneAndJuly.xlsx");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Workbook wb = null;
		try {
			wb = (Workbook) WorkbookFactory.create(productname);
		} catch (Exception e) {

			e.printStackTrace();
		}
		
		Sheet sh = wb.getSheetAt(0);

		Iterator<Row> itrrow = sh.rowIterator();

		ArrayList<ArrayList<String>> rowvalue = new ArrayList<ArrayList<String>>();

		DataFormatter dataFormatter = new DataFormatter();

		while (itrrow.hasNext()) {
			Row row = itrrow.next();
			Cell cell;
			for (int i = 0; i < row.getLastCellNum(); i++) {
				cell = row.getCell(i, Row.CREATE_NULL_AS_BLANK);
			}

			if (row.getRowNum() > 0) {
				ArrayList<String> cellvalue = new ArrayList<String>();
				Iterator<Cell> itrCell = row.cellIterator();
				while (itrCell.hasNext()) {
					cell = itrCell.next();
					cellvalue.add(dataFormatter.formatCellValue(cell).trim());
				}
				rowvalue.add(cellvalue);
			}
		}
		
		ArrayList<ArrayList<String>> result=new  ArrayList<ArrayList<String>>();
		int max=0;
		String hour=null;
		String lastdate = rowvalue.get(0).get(0);
		ArrayList<String> inter = new ArrayList<String>();
		System.out.println("Start : "+System.currentTimeMillis());
		for(ArrayList<String> outer:rowvalue)
		{
			inter=new ArrayList<String>();
			if(outer.get(0).equals(lastdate))
			{	
				if(max<=Integer.parseInt(outer.get(2)))
				{
					hour=outer.get(1);
					max=Integer.parseInt(outer.get(2));
				}
			}	
			else
			{
				inter.add(lastdate);
				inter.add(hour);
				inter.add(String.valueOf(max));
				result.add(inter);
				max=0;
				hour=null;
			}
			lastdate=outer.get(0);
		}
		inter.add(lastdate);
		inter.add(hour);
		inter.add(String.valueOf(max));
		result.add(inter);

		for(ArrayList<String> ans:result)
		{
			System.out.println(ans);
		}
		System.out.println("End : "+System.currentTimeMillis());	
	}
}
