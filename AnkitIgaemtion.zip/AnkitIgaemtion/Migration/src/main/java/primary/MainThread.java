package primary;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import base.CallWebService;
import base.ColumnWiseRead;
import base.Compare1x2x;
import base.FileToString;
import base.Logging;
import base.ReadProerties;
import base.TagPositionVerification;
import base.TagsVerification;
import base.UpdateInputRequestwithSpace;
import base.XMLVerificationCall;

public class MainThread extends Logging {

	public static String format = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss").format(new Date());
	public static ArrayList<String> OrderNumber = new ArrayList<String>();
	public static String MainfolderName = "CITI_BANK_Migration_" + ReadProerties.propsObjectsSplit("TestingType")
			+ "_Single_Joint_" + format;
	public static String SecnariofolderName=null;

	public static ArrayList<ArrayList<String>> callingRequest(String CallingType1, String CallingType2,
			String TemplateName, String inputFileName,String bureauseparator,String RequestFolderType) {
		logger.info(
				"==============================================================================================================================================");

		if(!new File(MainfolderName).exists())
		{
			new File(System.getProperty("user.dir")+File.separator+"OutputFiles"+ File.separator+MainfolderName).mkdir();

		}
		SecnariofolderName=MainfolderName+File.separator+RequestFolderType;
		
		logger.info("CITI_BANK_Migration_" + ReadProerties.propsObjectsSplit("TestingType") + "_TESTING_START_AT_"
				+ format);
		ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();

		Map<String, ArrayList<String>> tokens = ColumnWiseRead.columnWiseCalling(inputFileName);
		Map<String, String> token = new HashMap<>();
		int arrayListSize = 0;

		for (Map.Entry<String, ArrayList<String>> arrayCount : tokens.entrySet()) {
			arrayListSize = arrayCount.getValue().size();
		}
		int count = 0;
		int activeTestCaseOrderNumber=0;
		for (int itrNo = 0; itrNo < arrayListSize; itrNo++) {
			for (Map.Entry<String, ArrayList<String>> ankit : tokens.entrySet()) {
				token.put(ankit.getKey(), ankit.getValue().get(itrNo));
			}
			if (token.get("ACTIVE").equalsIgnoreCase("Y")) {
				ArrayList<String> responseValue = new ArrayList<String>();
				String xmlrequest;
				if(bureauseparator!=null)
				{
					xmlrequest = UpdateInputRequestwithSpace.UpdateTemplate(bureauseparator,TemplateName);
				}
				else
				{
					xmlrequest = FileToString.textToString(TemplateName);
				}
				ArrayList<String> TemplateList=new ArrayList<String>();
				TemplateList.add("MISMO1X_Single_Upgrade_TemplateName");
				TemplateList.add("MISMO1X_Joint_Upgrade_TemplateName");
				TemplateList.add("MISMO2X_Single_Reissue_TemplateName");
				TemplateList.add("MISMO2X_Joint_Reissue_TemplateName");
				TemplateList.add("MISMO2X_Single_Upgrade_Reissue_TemplateName");
				TemplateList.add("MISMO2X_Joint_Upgrade_Reissue_TemplateName");			
				TemplateList.add("FAME_Single_TemplateName");
				TemplateList.add("FAME_Joint_TemplateName");			
				
				if (TemplateList.contains(TemplateName)) {
//					System.out.println(activeTestCaseOrderNumber+"-"+OrderNumber.get(activeTestCaseOrderNumber));
					token.put("OrderNumber", OrderNumber.get(activeTestCaseOrderNumber++));
				}
				
				String patternString = "\\$\\{(" + StringUtils.join(token.keySet(), "|") + ")\\}";
				Pattern pattern = Pattern.compile(patternString);
				Matcher matcher = pattern.matcher(xmlrequest);
				StringBuffer requestString = new StringBuffer();
				while (matcher.find()) {
					matcher.appendReplacement(requestString, token.get(matcher.group(1)));
				}
				matcher.appendTail(requestString);
				responseValue = CallWebService.response(requestString.toString(),
						token.get("SSN1") + CallingType1 + "_Request", token.get("SSN1") + CallingType1 + "_Response",
						"xml", SecnariofolderName, inputFileName, token.get("SSN1"), TemplateName, token.get("Scenario"));

				if (!responseValue.get(1).equalsIgnoreCase("Connection time out")) {
					++count;
					responseValue.add(token.get("Scenario"));
					
					
					if (CallingType1.contains("_MISMO_1X_Request")) {/// 1X response tag verification
						responseValue.add(XMLVerificationCall.verifyXML(ReadProerties.propsObjectsSplit("M1xFile"),
								CallingType1, SecnariofolderName + File.separator + responseValue.get(2), token.get("SSN1"),
								inputFileName));

					 	String fileName = responseValue.get(2).replace("/", "\\");
						fileName = SecnariofolderName + File.separator + fileName;
						ArrayList<String> temp = new ArrayList<String>();

						MainThread.OrderNumber.add(TagsVerification
								.getChildNodeValue("//CREDITREPORT/CreditReportIdentifier", temp, fileName).get(1));
						
					} else if (CallingType1.contains("_MISMO_2X_Request")) { /// 2X response tag verification
						responseValue.add(XMLVerificationCall.verifyXML(ReadProerties.propsObjectsSplit("M2xFile"),
								CallingType1, SecnariofolderName + File.separator + responseValue.get(2), token.get("SSN1"),
								inputFileName));
						String fileName = responseValue.get(2).replace("/", "\\");
						fileName = SecnariofolderName + File.separator + fileName;
						ArrayList<String> temp = new ArrayList<String>();
						MainThread.OrderNumber.add(TagsVerification.getChildNodeAttribute(
								"//RESPONSE_GROUP/RESPONSE/RESPONSE_DATA/CREDIT_RESPONSE@CreditReportIdentifier", temp,
								fileName).get(1));
						responseValue.addAll(TagPositionVerification.Verification(
								SecnariofolderName + File.separator + inputFileName + File.separator + token.get("SSN1"),
								CallingType1));

						///Generating compare report for 1x and 2x response
						if (TemplateName.contains("FAME") || CallingType1.equalsIgnoreCase("_MISMO_2X_Request")) {
							responseValue.addAll(Compare1x2x.Compare(SecnariofolderName, token.get("SSN1"), inputFileName,
									CallingType1, CallingType2));
						
						}
					}
					data.add(responseValue);

				} else {
					logger.info(
							"Above system is down from this exectuion so stopping from this step, please try after some time");
					logger.info(
							"==============================================================================================================================================");
					System.exit(0);
				}
				logger.info(
						"==============================================================================================================================================");
			}
		}
		logger.info("Done with total " + count + " requests at " + new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss").format(new Date()));
		return data;
	}
}
