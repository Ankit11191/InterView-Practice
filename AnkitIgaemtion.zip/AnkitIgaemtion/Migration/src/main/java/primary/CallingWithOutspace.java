package primary;

import java.util.ArrayList;

import base.ConsolidatedReport;
import base.Logging;

public class CallingWithOutspace extends Logging {

	static ArrayList<ArrayList<String>> M1respose = new ArrayList<ArrayList<String>>();
	static ArrayList<ArrayList<String>> M2respose = new ArrayList<ArrayList<String>>();

	private static void rulesSubmit(String Message, String CallingType1, String TemplateName1, String inputFileName1,
			String CallingType2, String TemplateName2, String inputFileName2,String bureauseparator1X,String bureauseparator2X) {

		logger.info(Message);
		M1respose.addAll(MainThread.callingRequest(CallingType1, CallingType2, TemplateName1, inputFileName1,bureauseparator1X,"WithOutspaceInBureauIndicator"));
		M2respose.addAll(MainThread.callingRequest(CallingType2, CallingType1, TemplateName2, inputFileName2,bureauseparator2X,"WithOutspaceInBureauIndicator"));

		MainThread.OrderNumber.clear();
	}

	private static void rulesUpgrade(String Message, String CallingType1, String TemplateName1, String inputFileName1,
			String CallingType2, String TemplateName2, String inputFileName2, String upgradeInputFile,String bureauseparator1X,String bureauseparator2X) {

		logger.info(Message);
		MainThread.callingRequest(CallingType1, CallingType2, TemplateName1, inputFileName1,bureauseparator1X,"WithOutspaceInBureauIndicator");
		M1respose.addAll(MainThread.callingRequest(CallingType1, CallingType2, upgradeInputFile, inputFileName1,bureauseparator1X,"WithOutspaceInBureauIndicator"));
		M2respose.addAll(MainThread.callingRequest(CallingType2, CallingType1, TemplateName2, inputFileName2,bureauseparator2X,"WithOutspaceInBureauIndicator"));

		MainThread.OrderNumber.clear();
	}

	
	public static void Scenario1() {

		try {
			//////// Submit Request //////// 02 Scenarios ////////
			rulesSubmit("execution is strating for single Submit Request", "_MISMO_1X_Request",
					"MISMO1X_Single_Submit_TemplateName", "SingleSubmit", "_MISMO_2X_Request",
					"MISMO2X_Single_Reissue_TemplateName", "SingleSubmit", null, null);

			rulesSubmit("execution is strating for joint Submit Request", "_MISMO_1X_Request",
					"MISMO1X_Joint_Submit_TemplateName", "JointSubmit", "_MISMO_2X_Request",
					"MISMO2X_Joint_Reissue_TemplateName", "JointSubmit", null, null);

			//////// Upgrade Request //////// 10 Scenarios ////////
			rulesUpgrade("execution is strating for Single 12 Upgrade Request", "_MISMO_1X_Request",
					"MISMO1X_Single_Submit_TemplateName", "SingleUpgrade12", "_MISMO_2X_Request",
					"MISMO2X_Single_Upgrade_Reissue_TemplateName", "SingleUpgrade12",
					"MISMO1X_Single_Upgrade_TemplateName", null, null);

			rulesUpgrade("execution is strating for Joint 12 Upgrade Request", "_MISMO_1X_Request",
					"MISMO1X_Joint_Submit_TemplateName", "JointUpgrade12", "_MISMO_2X_Request",
					"MISMO2X_Joint_Upgrade_Reissue_TemplateName", "JointUpgrade12",
					"MISMO1X_Joint_Upgrade_TemplateName", null, null);

			rulesUpgrade("execution is strating for Single 23 Upgrade Request", "_MISMO_1X_Request",
					"MISMO1X_Single_Submit_TemplateName", "SingleUpgrade23", "_MISMO_2X_Request",
					"MISMO2X_Single_Upgrade_Reissue_TemplateName", "SingleUpgrade23",
					"MISMO1X_Single_Upgrade_TemplateName", null, null);

			rulesUpgrade("execution is strating for Joint 23 Upgrade Request", "_MISMO_1X_Request",
					"MISMO1X_Joint_Submit_TemplateName", "JointUpgrade23", "_MISMO_2X_Request",
					"MISMO2X_Joint_Upgrade_Reissue_TemplateName", "JointUpgrade23",
					"MISMO1X_Joint_Upgrade_TemplateName", null, null);

			rulesUpgrade("execution is strating for Single 21 Upgrade Request", "_MISMO_1X_Request",
					"MISMO1X_Single_Submit_TemplateName", "SingleUpgrade21", "_MISMO_2X_Request",
					"MISMO2X_Single_Upgrade_Reissue_TemplateName", "SingleUpgrade21",
					"MISMO1X_Single_Upgrade_TemplateName", null, null);

			rulesUpgrade("execution is strating for Joint 21 Upgrade Request", "_MISMO_1X_Request",
					"MISMO1X_Joint_Submit_TemplateName", "JointUpgrade21", "_MISMO_2X_Request",
					"MISMO2X_Joint_Upgrade_Reissue_TemplateName", "JointUpgrade21",
					"MISMO1X_Joint_Upgrade_TemplateName", null, null);

			rulesUpgrade("execution is strating for Single 32 Upgrade Request", "_MISMO_1X_Request",
					"MISMO1X_Single_Submit_TemplateName", "SingleUpgrade32", "_MISMO_2X_Request",
					"MISMO2X_Single_Upgrade_Reissue_TemplateName", "SingleUpgrade32",
					"MISMO1X_Single_Upgrade_TemplateName", null, null);

			rulesUpgrade("execution is strating for Joint 32 Upgrade Request", "_MISMO_1X_Request",
					"MISMO1X_Joint_Submit_TemplateName", "JointUpgrade32", "_MISMO_2X_Request",
					"MISMO2X_Joint_Upgrade_Reissue_TemplateName", "JointUpgrade32",
					"MISMO1X_Joint_Upgrade_TemplateName", null, null);

			rulesUpgrade("execution is strating for Add Borrower Request", "_MISMO_1X_Request",
					"MISMO1X_Single_Submit_TemplateName", "BorrowerAdd", "_MISMO_2X_Request",
					"MISMO2X_Joint_Upgrade_Reissue_TemplateName", "BorrowerAdd", "MISMO1X_Joint_Upgrade_TemplateName",
					null, null);

			rulesUpgrade("execution is strating for Remove Borrower Request", "_MISMO_1X_Request",
					"MISMO1X_Joint_Submit_TemplateName", "BorrowerRemove", "_MISMO_2X_Request",
					"MISMO2X_Single_Upgrade_Reissue_TemplateName", "BorrowerRemove",
					"MISMO1X_Single_Upgrade_TemplateName", null, null);

			//////// FMAC Request //////// 06 Scenarios ////////
			rulesSubmit("execution is strating for 1x Single Submit Request For FMAC", "_MISMO_1X_Request",
					"MISMO1X_Single_Submit_TemplateName", "FNMA1XSingleSubmit", "_MISMO_2X_Request",
					"FAME_Single_TemplateName", "FNMA1XSingleSubmit", null, null);
			rulesSubmit("execution is strating for 1x Single Submit error Scenario Request For FMAC",
					"_MISMO_1X_Request", "MISMO1X_Single_Submit_TemplateName", "FNMA1XSingleErrorSubmit",
					"_MISMO_2X_Request", "FAME_Single_TemplateName", "FNMA1XSingleErrorSubmit", null, null);
			rulesSubmit("execution is strating for 1x Joint Submit Request For FMAC", "_MISMO_1X_Request",
					"MISMO1X_Joint_Submit_TemplateName", "FNMA1XJointSubmit", "_MISMO_2X_Request",
					"FAME_Joint_TemplateName", "FNMA1XJointSubmit", null, null);

			rulesSubmit("execution is strating for 2x Single Submit Request For FMAC", "_MISMO_2X_Request_MC",
					"MISMO2X_Single_Submit_TemplateName", "FNMA2XSingleSubmit", "_MISMO_2X_Request_FMNA",
					"FAME_Single_TemplateName", "FNMA2XSingleSubmit", null, null);
			rulesSubmit("execution is strating for 2x Single Submit Request For FMAC", "_MISMO_2X_Request_MC",
					"MISMO2X_Single_Submit_TemplateName", "FNMA2XSingleErrorSubmit", "_MISMO_2X_Request_FMNA",
					"FAME_Single_TemplateName", "FNMA2XSingleErrorSubmit", null, null);
			rulesSubmit("execution is strating for 2x Joint Submit Request For FMAC", "_MISMO_2X_Request_MC",
					"MISMO2X_Joint_Submit_TemplateName", "FNMA2XJointSubmit", "_MISMO_2X_Request_FMNA",
					"FAME_Joint_TemplateName", "FNMA2XJointSubmit", null, null);			
		} finally {
			ConsolidatedReport.Consolidated(M1respose, M2respose);
		}
		logger.info(
				"==============================================================================================================================================");
	}
}
