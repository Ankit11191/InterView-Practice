package primary;

import base.ReadProerties;

public class testing {
	public static String createPath(String path)
	{
		String[] pathParts=path.split(",");
		String xpath="";
		for(int i=0;i<pathParts.length;i++)
		{
			if(ReadProerties.propsObjectsSplit(pathParts[i])==null)
			{
				xpath+=pathParts[i];
			}
			else
			{
				xpath+=ReadProerties.propsObjectsSplit(pathParts[i]);
			}
		}
//		first=xpath=//input[contains(text(),'
//		aftre=xpath=')]
		return xpath;
	}	
	public static void main(String[] args) {
		System.out.println(createPath("first,ankit,aftre"));
		//xpath=//input[contains(text(),'ankitxpath=')]
	}
}