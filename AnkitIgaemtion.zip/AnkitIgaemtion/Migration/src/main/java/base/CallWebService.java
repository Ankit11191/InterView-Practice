package base;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class CallWebService {

	private static String protocallType = ReadProerties.propsObjectsSplit("protocallType") + "://";
	private static String protocallType1 = ReadProerties.propsObjectsSplit("protocallType") + "://";
	
	private static String envName = ReadProerties.propsObjectsSplit("envName");
	private static String wsPAth = ReadProerties.propsObjectsSplit("wsPAth");

	private static String FNME = ReadProerties.propsObjectsSplit("FNME");
	private static String FNMEwsPAth = ReadProerties.propsObjectsSplit("FNMEwsPAth");
	
	private static String RGwsPAth = ReadProerties.propsObjectsSplit("MCRwsPAth");
	

	private static Response postAPI(String RequestString, String TemplateName) {
		try {			
			return RestAssured.given().contentType("application/xml").body(RequestString).when()
					.post(protocallType + envName + (TemplateName=="RGRequest_TemplateName"?RGwsPAth:wsPAth));
		} catch (Exception e) {
			Logging.logger.info(e.getLocalizedMessage() + " at : " + protocallType + envName + (TemplateName=="RGRequest_TemplateName"?RGwsPAth:wsPAth));
		}
		return null;
	}

	private static Response postAPIFMAE(String RequestString) {
		try {
			return RestAssured.given().contentType(ContentType.XML).body(RequestString).when()
					.post(protocallType1 + FNME + FNMEwsPAth);
		} catch (Exception e) {
			Logging.logger.info(e.getLocalizedMessage() + " at : " + protocallType1 + FNME + FNMEwsPAth);
		}
		return null;
	}

	@SuppressWarnings("unused")
	public static ArrayList<String> response(String RequestString, String RequestFileName, String ResponseFileName,
			String FileType, String FolderName,String requestTypeName, String SSN, String TemplateName,String  scenario) {

		Response response = null;
		String responseString=""; 
		WriteIntoFile1 writeIntoFile = new WriteIntoFile1();
		if (ReadProerties.propsObjectsSplit(TemplateName).split("\\.")[0].contains("FMAE")) 
		{
			response = postAPIFMAE(RequestString);
			
			while(!(response.statusCode()==200))
			{
				response = postAPIFMAE(RequestString);
			}
			if(response.getBody().asString().contains("Errors"))
			{
				responseString="Failed to get reponse from system for provided SSN or Order Number or may be some other internal error";
			}
			else
			{
				String postAPIFMAE=response.then().statusCode(200)
						.extract().xmlPath().getString("ns2:CreditResponse.CreditFiles.CreditFile[3].Data");
				byte[] FMAEResponseBytes=Base64.getDecoder().decode(postAPIFMAE);
			    for(int i = 0; i < FMAEResponseBytes.length; i++)
			    {
			    	responseString += (char)FMAEResponseBytes[i];
			    }
			}
		}
		else {
			response = postAPI(RequestString,TemplateName);
			responseString=response.getBody().asString();
		}
		ArrayList<String> result = new ArrayList<String>();
		if (response != null) {

			result.add(SSN);
			if (response.statusCode() == 200) {
				List<String> resultTemp = writeIntoFile.write(RequestString,responseString,
				RequestFileName, ResponseFileName, FileType, FolderName, requestTypeName);
				for (String value : resultTemp) {
					value = value.replace("\\", "/");
					result.add(value);
				}
				result.add(String.valueOf(response.statusCode()));
				if (response.statusCode() == 200) {
					result.add("Success");
				}

			} else {
				List<String> resultTemp = writeIntoFile.write(RequestString, response.getBody().asString(),
						RequestFileName, ResponseFileName, FileType, FolderName, requestTypeName);
				for (String value : resultTemp) {
					value = value.replace("\\", "/");
					result.add(value);
				}
				result.add(String.valueOf(response.statusCode()));
				if (response.statusCode() == 200) {
					result.add("Failed");
				}
			}
			return result;
		}
		else {
			result.add("null");
			result.add("Connection time out");
			result.add("Failed");
			return result;
		}

	}
}
