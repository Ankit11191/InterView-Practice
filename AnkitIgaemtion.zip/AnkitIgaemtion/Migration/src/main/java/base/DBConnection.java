package base;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

public class DBConnection extends Logging{

	static Connection conn = null;
	static ResultSet rs = null;
	static ResultSetMetaData rsMD;
	
	private static Statement callDBs(){
		
			try {
				
				Class.forName(ReadProerties.propsObjectsSplit("Driver"));

				conn = DriverManager.getConnection(ReadProerties.propsObjectsSplit("URL") + ReadProerties.propsObjectsSplit("DBname"), ReadProerties.propsObjectsSplit("Uname"),
					ReadProerties.propsObjectsSplit("Pass"));
				return(conn.createStatement());
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
	}
	
	private static void callStatement(String query)
	{
		try {
			callDBs().executeUpdate(query);
			conn.commit();
			logger.info(query+ "  --- Executed successfully");
		} catch (SQLException e) {
			logger.info(e.getLocalizedMessage());
		}finally {
			try {
				conn.close();
				rs.close();
				if (conn != null)
				{
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
	}
	public static void insertStatement(String query)
	{
		query=ReadProerties.propsObjectsSplit(query);
		callStatement(query);
	}
	
	public static void updateStatement(String query)
	{
		query = ReadProerties.propsObjectsSplit(query);
		callStatement(query);
	}
	
	public static void deleteStatement(String query)
	{
		query=ReadProerties.propsObjectsSplit(query);
		callStatement(query);
	}
	
	public static Map<String, String> selectStatement(String query)
	{		
		Map<String,String> hashMap = new HashMap<String,String>();

		try
		{
		rs = callDBs().executeQuery(ReadProerties.propsObjectsSplit(query));
		rsMD = rs.getMetaData();
		while (rs.next()) {
			for (int i = 1; i <= rsMD.getColumnCount(); i++) {
				String strColumnName = rsMD.getColumnName(i);
					hashMap.put(strColumnName, rs.getString(1));
			}
		}
	}
			catch (Exception e) {
		System.out.println(e);
	} finally {
			try {
				conn.close();
				rs.close();
				if (conn != null)
				{
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		logger.info(ReadProerties.propsObjectsSplit(query)+ "  --- Executed successfully");
		logger.info("value "+hashMap+"is avaiable ");
	return hashMap;
		}
	}
