package base;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class WriteIntoFile1 extends Logging {

//	public String fileName1 = ReadProerties.propsObjectsSplit("TemplateName")
//			+ new SimpleDateFormat("yyyy_MM_dd").format(new Date());

	public List<String> write(String requestString, String responseString, String requestFileName,
			String responseFileName, String fileType, String folderName, String requestTypeName) 
	{
		String[] requestResult = requestFileName.split("_");
		String[] responseResult = responseFileName.split("_");
		String folderStructure1 = System.getProperty("user.dir") + File.separator + "OutputFiles" + File.separator
				+ folderName;
		String folderStructure2 = folderStructure1 + File.separator + requestTypeName;
		String requestStructure = folderStructure2 + File.separator + requestResult[0];
		String responseStructure = folderStructure2 + File.separator + responseResult[0];
		File makdir1 = new File(folderStructure1);
		File makdir2 = new File(folderStructure2);
		File makdir3 = new File(requestStructure);
		File makdir4 = new File(responseStructure);
		if (!makdir3.exists()) {
			makdir1.mkdir();
			makdir2.mkdir();
			makdir3.mkdir();
			makdir4.mkdir();
		}

		requestFileName = requestFileName.replace("Requests_", "");

		String requestOutPutFileName = requestStructure + File.separator + requestFileName + ".xml";
		logger.info(requestResult[0] + " Request File is available at : " + requestOutPutFileName);

		try (BufferedWriter bw = new BufferedWriter(new FileWriter(requestOutPutFileName))) {
			bw.write(requestString);
		} catch (IOException e) {
			e.printStackTrace();
		}

		responseString = responseString.replace("<!DOCTYPE MORTGAGEDATA SYSTEM \"CreditReporting1_0_1.DTD\">", "");

		responseFileName = responseFileName.replace("Response_", "");
		String responseOutPutFileName = responseStructure + File.separator + responseFileName + "." + fileType;
		logger.info(responseResult[0] + " Response File is available at : " + responseOutPutFileName);

		try (BufferedWriter bw = new BufferedWriter(new FileWriter(responseOutPutFileName))) {
			bw.write(responseString);
		} catch (IOException e) {
			e.printStackTrace();
		}

		List<String> result = new ArrayList<String>();
		requestOutPutFileName = requestTypeName + File.separator + requestResult[0] + File.separator + requestFileName
				+ ".xml";
		responseOutPutFileName = requestTypeName + File.separator + responseResult[0] + File.separator
				+ responseFileName + "." + fileType;

		result.add(requestOutPutFileName);
		result.add(responseOutPutFileName);

		return result;
	}

}