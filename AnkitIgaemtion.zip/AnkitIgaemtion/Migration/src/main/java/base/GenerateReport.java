package base;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Hyperlink;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class GenerateReport extends Logging {

	public static String ConsolidatedExcelReport(ArrayList<ArrayList<String>> data, String FileFolder,
			String TargetFileName) {
		@SuppressWarnings("resource")
		Workbook workbook = new XSSFWorkbook();
		Sheet sheet = workbook.createSheet(FileFolder);
		sheet.protectSheet("");

		CreationHelper createHelper = workbook.getCreationHelper();

		Font headerFont = workbook.createFont();
		headerFont.setBold(true);
		headerFont.setFontHeightInPoints((short) 14);
		headerFont.setColor(IndexedColors.BLUE.getIndex());

		CellStyle headerCellStyle = workbook.createCellStyle();
		headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
		headerCellStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
		headerCellStyle.setBorderBottom(CellStyle.BORDER_THIN);
		headerCellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
		headerCellStyle.setBorderLeft(CellStyle.BORDER_THIN);
		headerCellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
		headerCellStyle.setBorderRight(CellStyle.BORDER_THIN);
		headerCellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
		headerCellStyle.setBorderTop(CellStyle.BORDER_THIN);
		headerCellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
		headerCellStyle.setFont(headerFont);
		Row headerRow = sheet.createRow(0);

		String[] columns = { "Scenario", "SSN", "MISMO 1X Request", "MISMO 1X Response", "MISMO 1X Report",
				"MISMO 2X Request", "MISMO 2X Response", "MISMO 2X Report", "MISMO 2X Position Order Report",
				"Position Order Matched Count", "Position Order UnMatched Count", " Comparison Report",
				"MISMO 1X Count", "MISMO 2X Count", "Match Count", "UnMatch Count", "Additional Tags Count" };
		for (int i = 0; i < columns.length; i++) {
			Cell cell = headerRow.createCell(i);
			if (columns[i] != null) {
				cell.setCellValue(columns[i]);
			} else {
				cell.setCellValue(i);
			}
			cell.setCellStyle(headerCellStyle);
		}

		int rowNum = 1;
		for (ArrayList<String> rowData : data) {
			Font fontColur = workbook.createFont();
			CellStyle cellStyle = workbook.createCellStyle();
			cellStyle.setBorderBottom(CellStyle.BORDER_THIN);
			cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
			cellStyle.setBorderLeft(CellStyle.BORDER_THIN);
			cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
			cellStyle.setBorderRight(CellStyle.BORDER_THIN);
			cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
			cellStyle.setBorderTop(CellStyle.BORDER_THIN);
			cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
			int cellNum = 0;
			Row row = sheet.createRow(rowNum++);
			for (String cellData : rowData) {
				Cell cell = row.createCell(cellNum++);
				fontColur.setColor(IndexedColors.BLACK.getIndex());
				cellStyle.setFont(fontColur);
				cell.setCellValue(cellData.split("/")[cellData.split("/").length - 1]);
				if (cellNum >= 3 && cellNum <= 9 || cellNum == 12) {
					Hyperlink link = (Hyperlink) createHelper.createHyperlink(Hyperlink.LINK_URL);
					link.setAddress(cellData);
					cell.setHyperlink((Hyperlink) link);
				} else if ((cellNum == 16 && Integer.valueOf(cellData) > 0)
						|| (cellNum == 17 && Integer.valueOf(cellData) > 10)
						|| (cellNum == 11 && Integer.valueOf(cellData) > 0)) {
					cellStyle.setFillForegroundColor(IndexedColors.LIGHT_YELLOW.getIndex());
					cellStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
					fontColur.setColor(IndexedColors.RED.getIndex());
				} else if ((cellNum == 10 && Integer.valueOf(cellData) == 1)
						|| (cellNum == 11 && Integer.valueOf(cellData) == 1)) {
					cellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
					cellStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
					fontColur.setColor(IndexedColors.RED.getIndex());
				}
				cell.setCellStyle(cellStyle);
			}
		}
		for (int i = 0; i < columns.length; i++) {
			sheet.autoSizeColumn(i);
		}

		File makdir = new File(
				System.getProperty("user.dir") + File.separator + "OutputFiles" + File.separator + FileFolder);
		if (!makdir.exists()) {
			makdir.mkdir();
		}
		FileOutputStream fileOut = null;
		try {
			String filePath = System.getProperty("user.dir") + File.separator + "OutputFiles" + File.separator
					+ FileFolder + File.separator + TargetFileName + ".xlsx";
			fileOut = new FileOutputStream(filePath);

			workbook.write(fileOut);
			fileOut.close();
			if (data.get(0).size() == 5) {
				logger.info("==============================================================================================================================================");
				logger.info("Compared file is availbale at : " + filePath);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Success";

	}

	public static String[] M2XTagPositionReport(Map<Integer, ArrayList<String>> data, String FileFolder,
			String TargetFileName) {
		@SuppressWarnings("resource")
		Workbook workbook = new XSSFWorkbook();
		Sheet sheet = workbook.createSheet("M2XTag Position Verification");
		sheet.protectSheet("");

		Font headerFont = workbook.createFont();
		headerFont.setBold(true);
		headerFont.setFontHeightInPoints((short) 14);
		headerFont.setColor(IndexedColors.BLUE.getIndex());

		CellStyle headerCellStyle = workbook.createCellStyle();
		headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
		headerCellStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
		headerCellStyle.setBorderBottom(CellStyle.BORDER_THIN);
		headerCellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
		headerCellStyle.setBorderLeft(CellStyle.BORDER_THIN);
		headerCellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
		headerCellStyle.setBorderRight(CellStyle.BORDER_THIN);
		headerCellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
		headerCellStyle.setBorderTop(CellStyle.BORDER_THIN);
		headerCellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
		headerCellStyle.setFont(headerFont);
		Row headerRow = sheet.createRow(0);

		String[] columns = { "Position", "Expected TagName", "Actual TagName", "Result" };
		for (int i = 0; i < columns.length; i++) {
			Cell cell = headerRow.createCell(i);
			if (columns[i] != null) {
				cell.setCellValue(columns[i]);
			} else {
				cell.setCellValue(i);
			}
			cell.setCellStyle(headerCellStyle);
		}

		int rowNum = 1;
		for (Entry<Integer, ArrayList<String>> rowData : data.entrySet()) {
			Font fontColur = workbook.createFont();
			CellStyle cellStyle = workbook.createCellStyle();
			cellStyle.setBorderBottom(CellStyle.BORDER_THIN);
			cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
			cellStyle.setBorderLeft(CellStyle.BORDER_THIN);
			cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
			cellStyle.setBorderRight(CellStyle.BORDER_THIN);
			cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
			cellStyle.setBorderTop(CellStyle.BORDER_THIN);
			cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
			int cellNum = 0;
			Row row = sheet.createRow(rowNum++);
			Cell cell = row.createCell(cellNum++);
			fontColur.setColor(IndexedColors.BLACK.getIndex());
			cellStyle.setFont(fontColur);
			cell.setCellValue(rowData.getKey());
			cell.setCellStyle(cellStyle);

			for (String cellData : rowData.getValue()) {
				cell = row.createCell(cellNum++);
				fontColur.setColor(IndexedColors.BLACK.getIndex());
				cellStyle.setFont(fontColur);
				cell.setCellValue(cellData);
				cell.setCellStyle(cellStyle);
			}
			cell = row.createCell(cellNum++);
			fontColur.setColor(IndexedColors.BLACK.getIndex());
			cellStyle.setFont(fontColur);
			cell.setCellValue(rowData.getValue().get(0).equals(rowData.getValue().get(1)) ? "True" : "False");
			cell.setCellStyle(cellStyle);
		}
		for (int i = 0; i < columns.length; i++) {
			sheet.autoSizeColumn(i);
		}

		File makdir = new File(
				System.getProperty("user.dir") + File.separator + "OutputFiles" + File.separator + FileFolder);
		if (!makdir.exists()) {
			makdir.mkdir();
		}
		FileOutputStream fileOut = null;
		String filePath = null;
		try {
			filePath = System.getProperty("user.dir") + File.separator + "OutputFiles" + File.separator + FileFolder
					+ File.separator + TargetFileName + ".xlsx";
			fileOut = new FileOutputStream(filePath);

			workbook.write(fileOut);
			fileOut.close();
			logger.info("Tag Verification file is availbale at : " + filePath);

		} catch (Exception e) {
			e.printStackTrace();
		}
		String[] retrn = { "Success", filePath };
		return retrn;

	}

	public static String[] XMLOutputinExcel(ArrayList<ArrayList<String>> data, String FileFolder, String subFileFolder,
			String TargetFileName, String requtestType) {

		@SuppressWarnings("resource")
		Workbook workbook = new XSSFWorkbook();
		Sheet sheet = workbook.createSheet(subFileFolder);
		sheet.protectSheet("");

		Font headerFont = workbook.createFont();
		headerFont.setBold(true);
		headerFont.setFontHeightInPoints((short) 14);
		headerFont.setColor(IndexedColors.BLUE.getIndex());

		CellStyle headerCellStyle = workbook.createCellStyle();
		headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
		headerCellStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
		headerCellStyle.setBorderBottom(CellStyle.BORDER_THIN);
		headerCellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
		headerCellStyle.setBorderLeft(CellStyle.BORDER_THIN);
		headerCellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
		headerCellStyle.setBorderRight(CellStyle.BORDER_THIN);
		headerCellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
		headerCellStyle.setBorderTop(CellStyle.BORDER_THIN);
		headerCellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
		headerCellStyle.setFont(headerFont);
		Row headerRow = sheet.createRow(0);

		String[] columns = new String[data.get(0).size()];
		if (data.get(0).size() == 2) {
			columns[0] = "Tag Name";
			columns[1] = "Value";
		} else if (data.get(0).size() == 5 && requtestType.contains("FNMA1X")) {
			columns[0] = "FNMA Tag Name";
			columns[1] = "FNMA Tag Value";
			columns[2] = "MISMO 1X Tag Name";
			columns[3] = "MISMO 1X Tag Value";
			columns[4] = "Result";

		}else if (data.get(0).size() == 5 && requtestType.contains("FNMA2X")) {
			columns[0] = "FNMA Tag Name";
			columns[1] = "FNMA Tag Value";
			columns[2] = "MISMO 2X Tag Name";
			columns[3] = "MISMO 2X Tag Value";
			columns[4] = "Result";

		} else if(data.get(0).size() == 5)  {
			columns[0] = "MISMO 2X Tag Name";
			columns[1] = "MISMO 2X Tag Value";
			columns[2] = "MISMO 1X Tag Name";
			columns[3] = "MISMO 1X Tag Value";
			columns[4] = "Result";

		}
		
		for (int i = 0; i < columns.length; i++) {
			Cell cell = headerRow.createCell(i);
			if (columns[i] != null) {
				cell.setCellValue(columns[i]);
			} else {
				cell.setCellValue(i);
			}
			cell.setCellStyle(headerCellStyle);
		}

		int rowNum = 1;
		for (ArrayList<String> rowData : data) {
			Font fontColur = workbook.createFont();
			CellStyle cellStyle = workbook.createCellStyle();
			cellStyle.setBorderBottom(CellStyle.BORDER_THIN);
			cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
			cellStyle.setBorderLeft(CellStyle.BORDER_THIN);
			cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
			cellStyle.setBorderRight(CellStyle.BORDER_THIN);
			cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
			cellStyle.setBorderTop(CellStyle.BORDER_THIN);
			cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
			int cellNum = 0;
			Row row = sheet.createRow(rowNum++);
			for (String cellData : rowData) {
				Cell cell = row.createCell(cellNum++);
				if (cellData == "No such elemnt found" || cellData == "Not Matched") {
					fontColur.setColor(IndexedColors.RED.getIndex());
					cellStyle.setFont(fontColur);
					cell.setCellValue(cellData);
					cell.setCellStyle(cellStyle);
					continue;
				} else if (cellData == "This attribute is not available for MISMO 1X response") {
					fontColur.setColor(IndexedColors.CORNFLOWER_BLUE.getIndex());
					cellStyle.setFont(fontColur);
					cell.setCellValue(cellData);

					cell.setCellStyle(cellStyle);
					continue;
				} else {
					fontColur.setColor(IndexedColors.BLACK.getIndex());
					cellStyle.setFont(fontColur);
					cell.setCellValue(cellData);
					cell.setCellStyle(cellStyle);
				}
			}
		}
		for (int i = 0; i < columns.length; i++) {
			sheet.autoSizeColumn(i);
		}

		File makdir = new File(
				System.getProperty("user.dir") + File.separator + "OutputFiles" + File.separator + FileFolder);
		if (!makdir.exists()) {
			makdir.mkdir();
		}
		FileOutputStream fileOut = null;
		String filePath = requtestType + File.separator + subFileFolder + File.separator + TargetFileName
		+ "_Attribute_Verification" + ".xlsx";

		try {
			
			String filePath1 = System.getProperty("user.dir") + File.separator + "OutputFiles" + File.separator + FileFolder
					+ File.separator + requtestType + File.separator + subFileFolder + File.separator +TargetFileName
					+ "_Attribute_Verification" + ".xlsx";
			fileOut = new FileOutputStream(filePath1);

			workbook.write(fileOut);
			fileOut.close();
			if (data.get(0).size() == 5) {
				logger.info("Compared file is availbale at : " + filePath1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		String[] retrn = { "Success", filePath};
		return retrn;

	}

}
