package base;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Compare1x2x {
	public static ArrayList<String> Compare(String folderName, String subFolderName, String requestType,
			String CallingType1, String CallingType2) {

		
		
		Map<String, String> m1xExtract = new HashMap<String, String>();
		if (CallingType2.equalsIgnoreCase("_MISMO_2X_Request_MC")) {
			m1xExtract = MISMOOperation.M1xExtract(
					"OutputFiles" + File.separator + folderName + File.separator + requestType + File.separator
							+ subFolderName + File.separator + CallingType1 + "_Attribute_Verification.xlsx");
		} else {
			m1xExtract = MISMOOperation.M2xExtract(
					"OutputFiles" + File.separator + folderName + File.separator + requestType + File.separator
							+ subFolderName + File.separator + CallingType1 + "_Attribute_Verification.xlsx");
		}
		Map<String, String> m2xExtract = MISMOOperation
				.M1xExtract("OutputFiles" + File.separator + folderName + File.separator + requestType + File.separator
						+ subFolderName + File.separator + CallingType2 + "_Attribute_Verification.xlsx");

		ArrayList<ArrayList<String>> result = new ArrayList<ArrayList<String>>();

		Map<String, String> M2XRemaining = new HashMap<String, String>();

		ArrayList<String> ReportResult = new ArrayList<String>();
		{
			for (Map.Entry<String, String> res2 : m2xExtract.entrySet()) {
				boolean status = false;
				ArrayList<String> temp = new ArrayList<String>();
				for (Map.Entry<String, String> res1 : m1xExtract.entrySet()) {
					if (res1.getKey().equals(res2.getKey())) {
						temp.add(res1.getKey());
						temp.add(res1.getValue());
						temp.add(res2.getKey());
						temp.add(res2.getValue());
						if (res1.getValue().equals(res2.getValue())) {
							temp.add("Matched");
						} else {
							temp.add("Not Matched");
						}
						status = true;
					}
				}
				if (status == false) {
					M2XRemaining.put(res2.getKey(), res2.getValue());
				}
				if (temp.size() > 0) {
					result.add(temp);
				}
			}
		}

		for (Map.Entry<String, String> newAttrib : M2XRemaining.entrySet()) {
			ArrayList<String> temp1 = new ArrayList<String>();
			temp1.add(null);
			temp1.add(null);
			temp1.add(newAttrib.getKey());
			temp1.add(newAttrib.getValue());
			temp1.add("This attribute is not available for MISMO 1X response");
			result.add(temp1);
		}
		int mac = 0, Nmac = 0;
		for (ArrayList<String> res : result) {
			if (res.get(4).equals("Matched")) {
				mac++;
			} else if (res.get(4).equals("Not Matched")) {
				Nmac++;
			}
		}

		ReportResult.add(GenerateReport.XMLOutputinExcel(result, folderName, subFolderName, "Compare", requestType)[1]
				.replace("\\", "/"));
		ReportResult.add(Integer.toString(m1xExtract.size()));
		ReportResult.add(Integer.toString(m2xExtract.size()));
		ReportResult.add(Integer.toString(mac));
		ReportResult.add(Integer.toString(Nmac));
		ReportResult.add(Integer.toString(M2XRemaining.size()));

		return ReportResult;
	}
}
