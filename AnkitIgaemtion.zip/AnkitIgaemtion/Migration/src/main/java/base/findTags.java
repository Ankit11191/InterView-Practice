package base;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class findTags {
	/// https://stackoverflow.com/questions/36179764/get-path-to-all-xmls-nodes

	public static String getNodePath(Node node) {

		StringBuilder pathBuilder = new StringBuilder("/");
		pathBuilder.append(node.getNodeName());

		Node currentNode = node;

		if (currentNode.getNodeType() != Node.DOCUMENT_NODE) {
			while (currentNode.getParentNode() != null) {
				currentNode = currentNode.getParentNode();

				if (currentNode.getNodeType() == Node.DOCUMENT_NODE) {
					break;
				} else if (getIndexOfArrayNode(currentNode) != null) {
					pathBuilder.insert(0,
							"/" + currentNode.getNodeName() + "[" + getIndexOfArrayNode(currentNode) + "]");
				} else {
					pathBuilder.insert(0, "/" + currentNode.getNodeName());
				}

			}
		}
		return pathBuilder.toString();
	}

	private static boolean isArrayNode(Node node) {
		//node = 
		if (node.getNextSibling() == null) {
			return false;
		} else {
			return (node.getNextSibling() != null && node.getNextSibling().getNodeName().equalsIgnoreCase(node.getNodeName()))
					|| (node.getPreviousSibling() != null && node.getPreviousSibling().getNodeName().equalsIgnoreCase(node.getNodeName()));
		}
	}

	private static Integer getIndexOfArrayNode(Node node) {

		if (isArrayNode(node)) {
			int leftCount = 0;
			Node currentNode = node.getPreviousSibling();
			while (currentNode != null) {
				leftCount++;
				currentNode = currentNode.getPreviousSibling();
			}
			return leftCount;
		} else {
			return null;
		}
	}

	public static List<String> callattributes(String path, Node node) {
		int count = path.toString().length();
		List<String> list = new ArrayList<String>();
		if (node.hasAttributes()) {
			StringBuilder pathBuilderq = null;

			NamedNodeMap attributes = node.getAttributes();
			for (int i = 0; i < attributes.getLength(); i++) {
				pathBuilderq = new StringBuilder(path);
				list.add(pathBuilderq.insert(count, "@" + attributes.item(i).getNodeName()).toString() + " if");
			}
		} /*else if (node.hasChildNodes() && node.hasAttributes() && node.getChildNodes().item(0) != null) {
			list.add(path + " else if");
		}*/
		return list;
	}

	public static void main(String[] args) throws Exception {

		File file = new File("C:/Eclips/Migration/DownloadedFiles/asha.xml");
		XPath xPath = XPathFactory.newInstance().newXPath();
		String expression = "//*"; // "//*","following-sibling::*[1]";

		Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(file);
		document.getDocumentElement().normalize();

		NodeList nodeList = (NodeList) xPath.compile(expression).evaluate(document, XPathConstants.NODESET);

		for (int i = 0; i < nodeList.getLength(); i++) {
/*			System.out.println(nodeList.item(i).getNodeName() + " - " + nodeList.item(i).hasChildNodes() + " - "
					+ nodeList.item(i).hasAttributes() + " - "
					+ nodeList.item(i).getChildNodes().item(0).getNextSibling() +" - "+nodeList.item(i).getNextSibling().getNodeName().equalsIgnoreCase(nodeList.item(i).getNodeName()));*/
			
			System.out.println("getPreviousSibling : "+nodeList.item(i).getPreviousSibling());
			System.out.println(getNodePath(nodeList.item(i)));

			// System.out.println(callattributes(getNodePath(nodeList.item(i)),nodeList.item(i)));
		}
	}
}
