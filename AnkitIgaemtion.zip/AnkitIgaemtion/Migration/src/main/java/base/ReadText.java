package base;

import java.io.BufferedReader;
import java.io.FileReader;

public class ReadText {

	public static String read(String FilePath){
		String str ="";
		try {
//			FilePath=System.getProperty("user.dir") + File.separator + "OutputFiles"+ File.separator+FilePath;
			FileReader document = new FileReader(FilePath);
			BufferedReader bufferedReader = new BufferedReader(document);
			String line = bufferedReader.readLine();
			str=line;
			bufferedReader.close();         
            }

		catch(Exception e)
		{
			Logging.logger.info(e.getLocalizedMessage());
		}
		return str;
	}

}
