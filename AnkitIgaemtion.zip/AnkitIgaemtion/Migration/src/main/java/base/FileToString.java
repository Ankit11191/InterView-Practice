package base;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class FileToString extends Logging {

	public static String textToString(String TemplateName) {
		File file = new File(System.getProperty("user.dir") + File.separator + "Templates" + File.separator
					+ ReadProerties.propsObjectsSplit(TemplateName));
		
		String line = "";
		String oldtext = "";
		BufferedReader reader = null;

		try {
			reader = new BufferedReader(new FileReader(file));
			while ((line = reader.readLine()) != null) {
				oldtext += line + "\r\n";
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return oldtext;
	}
}