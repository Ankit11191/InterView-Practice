package base;

import java.io.File;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


public class TagsVerification {
	static Document document = null;
	public static Document fileRead(String filepath)
	{
		File xmlFilePath=new File(System.getProperty("user.dir")+File.separator+"OutputFiles"+File.separator+filepath);

		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = null;
		document = null;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			document=dBuilder.parse(xmlFilePath);
		} catch (Exception e) {
			e.printStackTrace();
		}
		document.getDocumentElement().normalize();
		return document;
	}
	
	public static ArrayList<String> getParentNodeAttribute(String xpathName,ArrayList<String> OutPutData, String filepath) {
		OutPutData.add(xpathName);
		if(ReadText.read(System.getProperty("user.dir")+File.separator+"OutputFiles"+File.separator+filepath).contains("Failed to get reponse from system for provided SSN or Order Number or may be some other internal error"))
		{
			OutPutData.add("Failed to get reponse from system");
		}
		else if(fileRead(filepath).getDocumentElement().getAttribute(xpathName).length()!=0)
		{
			OutPutData.add(fileRead(filepath).getDocumentElement().getAttribute(xpathName));
		}
		else
		{
			OutPutData.add("No such elemnt found");
		}
		return OutPutData;
	}
	
	public static ArrayList<String> getChildNodeValue(String xpathName,ArrayList<String> OutPutData, String filepath) {
		    XPath xpath = XPathFactory.newInstance().newXPath();
		    XPathExpression expr;
		    OutPutData.add(xpathName);
		    if(ReadText.read(System.getProperty("user.dir")+File.separator+"OutputFiles"+File.separator+filepath).contains("Failed to get reponse from system for provided SSN or Order Number or may be some other internal error"))
			{
				OutPutData.add("Failed to get reponse from system");
			}
		    else
		    {
				try {
					expr = xpath.compile(xpathName);
					NodeList nodeList = (NodeList) expr.evaluate(fileRead(filepath), XPathConstants.NODESET);
	
					if(nodeList.getLength()!=0)
					{
						OutPutData.add(nodeList.item(0).getTextContent());
					}
					else
					{
						OutPutData.add("No such elemnt found");
					}
				} catch (XPathExpressionException ex) {
					System.err.println("unable to load XML: " + ex);
				}
		    }
		return OutPutData;
	}

	public static ArrayList<String> getChildNodeAttribute(String xpathName,ArrayList<String> OutPutData, String filepath) {
	    XPath xpath = XPathFactory.newInstance().newXPath();
	    String[] xPATHSplit= xpathName.split("@");
	    String MainxPATH=xPATHSplit[0];
	    String xPATHChild=xPATHSplit[1];
	    OutPutData.add(xpathName);
	    if(ReadText.read(System.getProperty("user.dir")+File.separator+"OutputFiles"+File.separator+filepath).contains("Failed to get reponse from system for provided SSN or Order Number or may be some other internal error"))
		{
			OutPutData.add("Failed to get reponse from system");
		}
	    else
	    {
			try {
				NodeList nodeList = (NodeList) xpath.compile(MainxPATH).evaluate(fileRead(filepath), XPathConstants.NODESET);
	
				if(nodeList.getLength()!=0)
				{
					Node node=nodeList.item(0);
					Element element=(Element) node;
					if(element.getAttribute(xPATHChild).length()!=0)
					{
						OutPutData.add(element.getAttribute(xPATHChild));
					}
					else
					{
						OutPutData.add("No such elemnt found");
					}
				}
				else
				{
					OutPutData.add("No such elemnt found");
				}
			} catch (XPathExpressionException ex) {
				System.err.println("unable to load XML: " + ex);
			}
	    }
	return OutPutData;
	}
}