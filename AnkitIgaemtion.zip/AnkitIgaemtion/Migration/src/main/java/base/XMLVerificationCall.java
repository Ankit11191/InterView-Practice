package base;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

import primary.MainThread;

public class XMLVerificationCall extends Logging{
	
	public static String verifyXML(String sourceFileName, String TargetFileName, String filepath,String subFolder, String requestType) {
		
		ArrayList<ArrayList<String>> name=ReadFromExcelFile.getCellValue("XMLVerificationTagFiles"+File.separator+sourceFileName+".xlsx");

		ArrayList<ArrayList<String>> OutPutRow=new ArrayList<ArrayList<String>>();
		
		for(ArrayList<String> inner :name)
		{	ArrayList<String> RowData=new ArrayList<String>();
			String[] ivalue=inner.toArray(new String[0]);
			String[] stepDefination=Arrays.copyOfRange(ivalue, 1, ivalue.length);
			if(ivalue[0].equalsIgnoreCase("Y"))
			{
				OutPutRow.add(XMLVerificationMethodFactory.methods(stepDefination,RowData, filepath));
			}
		}
		String[] res=GenerateReport.XMLOutputinExcel(OutPutRow, MainThread.SecnariofolderName,subFolder,TargetFileName,requestType);

		if(res[0]=="Success")
		{
			logger.info("Attribute Verification File Print Successfully. Please find at location : "+System.getProperty("user.dir") + File.separator + "OutputFiles"+ 
					File.separator+MainThread.SecnariofolderName+File.separator+requestType+ File.separator+subFolder+ File.separator +TargetFileName+"_Attribute_Verification.xlsx");
		}
		else
		{
			logger.info("Please see error Log");
		}
		return res[1].replace("\\", "/");
	}	
}
