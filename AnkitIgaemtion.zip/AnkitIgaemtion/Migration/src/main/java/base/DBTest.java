package base;

public class DBTest {

	public static void main(String[] args) {
		System.out.println(DBConnection.selectStatement("Query1"));
	}

}
