package base;

import java.util.ArrayList;


public class XMLVerificationMethodFactory extends Logging{
	
	public static ArrayList<String> methods(String[] SelectAction, ArrayList<String> RowData, String filepath)
	{
		ArrayList<String> returnData=new ArrayList<String>();
		String Action=SelectAction[1].toLowerCase();
		switch (Action) 
		{
			case "getparentnodeattribute":

				returnData = TagsVerification.getParentNodeAttribute(SelectAction[0],RowData, filepath);
				break;
			
			case "getchildnodevalue":

				returnData = TagsVerification.getChildNodeValue(SelectAction[0],RowData, filepath);
				break;
				
			case "getchildnodeattribute":

				returnData = TagsVerification.getChildNodeAttribute(SelectAction[0],RowData, filepath);
				break;
				
			default:
				logger.info("For "+Action+" Element "+SelectAction[0]+" is not available");
				break;
		}
		return returnData;
	}
}
