package base;

import java.io.File;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

public class ReadPDF {

	public static void main(String[] args){
		try {
			PDDocument document = PDDocument.load(new File("C:/Eclips/Migration/DownloadedFiles/J3RZJ6.pdf"));

            if (!document.isEncrypted()) {
			
                PDFTextStripper tStripper = new PDFTextStripper();

                String pdfFileInText = tStripper.getText(document);
                
                String a="Equifax Information Svc. LLC P.O. Box 740341 Atlanta, GA 30374 800-685-1111 www.equifax.com";
                

                String lines[] = pdfFileInText.split("\\r?\\n");
                StringBuffer buffer=new StringBuffer();
                for (String line : lines) {
                   buffer.append(line+" ");
                }
                if(buffer.toString().contains(a))
                {
                	System.out.println("Ankit is best");
                }
            }

        }
		catch(Exception e)
		{
			System.out.println(e.getLocalizedMessage());
		}
	}

}
