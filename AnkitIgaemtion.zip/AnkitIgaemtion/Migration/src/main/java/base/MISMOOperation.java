package base;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MISMOOperation {
	
	public static Map<String, String> M2xExtract(String filePath) {
		ArrayList<ArrayList<String>> cellValue = ReadFromExcelFile.getCellValue(filePath);

		Map<String, String> NameMap = new HashMap<String, String>();
		Map<String, String> ValueMap = new HashMap<String, String>();
		
		Map<String, String> M2XMap = new HashMap<String, String>();

		for(ArrayList<String> m1: cellValue)
		{
				if(m1.get(0).contains("_Name"))
				{
					NameMap.put(m1.get(0).replace("@_Name", ""), m1.get(1));
				}
				else if(m1.get(0).contains("_Value"))
				{
					ValueMap.put(m1.get(0).replace("@_Value", ""), m1.get(1));
				}
		}
		
		
		for(Map.Entry<String, String> m3: NameMap.entrySet())
		{
			for(Map.Entry<String, String> m4: ValueMap.entrySet())
			{
				if(m3.getKey().equals(m4.getKey()))
				{
					M2XMap.put(m3.getValue(), m4.getValue());
				}
			}
		}
		return M2XMap;
	}
	
	public static Map<String, String> M1xExtract(String filePath) {
		ArrayList<ArrayList<String>> cellValue = ReadFromExcelFile.getCellValue(filePath);
		Map<String, String> M1XMap = new HashMap<String, String>();
		for(ArrayList<String> m1: cellValue)
		{
			String[] val= m1.get(0).split("/");
			M1XMap.put(val[val.length-1],m1.get(1));
		}
		return M1XMap;
	}
}
