package base;

import java.util.ArrayList;
import java.util.Iterator;

import primary.MainThread;

public class ConsolidatedReport {
	
	public static void Consolidated(ArrayList<ArrayList<String>> M1, ArrayList<ArrayList<String>> M2)
	{
		Iterator<ArrayList<String>> i1=M1.iterator();
		Iterator<ArrayList<String>> i2=M2.iterator();
		ArrayList<ArrayList<String>> M=new ArrayList<ArrayList<String>>();
		
		while(i1.hasNext() || i2.hasNext())
		{
			ArrayList<String> l1=i1.next();
			ArrayList<String> l2=i2.next();
			ArrayList<String> arr=new ArrayList<String>();
			arr.add(l1.get(5));
			arr.add(l1.get(0));
			arr.add(l1.get(1));
			arr.add(l1.get(2));
			arr.add(l1.get(6));
			arr.add(l2.get(1));
			arr.add(l2.get(2));
			arr.add(l2.get(6));
			arr.add(l2.get(7));
			arr.add(l2.get(8));
			arr.add(l2.get(9));
			arr.add(l2.get(10));
			arr.add(l2.get(11));
			arr.add(l2.get(12));
			arr.add(l2.get(13));
			arr.add(l2.get(14));
			arr.add(l2.get(15));

			M.add(arr);
		}
		GenerateReport.ConsolidatedExcelReport(M, MainThread.SecnariofolderName, "_Consolidated_Report");

		
	}
}
