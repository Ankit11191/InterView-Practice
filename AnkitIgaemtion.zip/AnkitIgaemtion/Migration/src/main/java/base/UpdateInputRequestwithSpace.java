package base;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UpdateInputRequestwithSpace {

	private static String ReadFile(String filepath) {
		StringBuffer stringBuffer = null;
		try {
			File file = new File(filepath);
			FileReader fileReader = new FileReader(file);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			stringBuffer = new StringBuffer();
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				stringBuffer.append(line);
			}
			fileReader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return stringBuffer.toString();
	}
	
	public static String UpdateTemplate(String bureauName,String TemplateName){

		String Fpath=System.getProperty("user.dir") + File.separator + "Templates" + File.separator
				+ ReadProerties.propsObjectsSplit(TemplateName);
		String text=ReadFile(Fpath);

		Path path = Paths.get(Fpath);
	    Charset charset = StandardCharsets.UTF_8;

		String content = null;
		try {
			content = new String(Files.readAllBytes(path), charset);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		String[] bureauNameSplit = bureauName.split(",");
		for(String burName : bureauNameSplit)
		{
			String searchTerm = burName;

			String sPattern = Pattern.quote(searchTerm);
			StringBuilder result = new StringBuilder();
			Pattern pattern = Pattern.compile(sPattern);
		    Matcher matcher = pattern.matcher(text);
		    while (matcher.find()) {
		        result.append(matcher.group()).append('=');
		    }
		    
		    String fromValue = result.toString().trim();

		    String toValue=searchTerm+" = ";
		    
			content = content.replaceAll(fromValue, toValue);
		}
		
		return 	content;	
	}
}
