package base;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class TagPositionVerification {

	public static ArrayList<String> Verification(String path, String callingType) {
		ArrayList<ArrayList<String>> Actual = ReadFromExcelFile.getCellValue("XMLVerificationTagFiles"+File.separator+ReadProerties.propsObjectsSplit("tagpositionFile"));
		ArrayList<ArrayList<String>> Expected = ReadFromExcelFile.getCellValue("OutputFiles"+File.separator+path+File.separator+callingType+"_Attribute_Verification.xlsx");
		ArrayList<String> result = new ArrayList<String>();
		Map<String, String> actMap= new HashMap<String, String>();
		Map<String, String> exptMap=new HashMap<String, String>();
		
		Map<Integer, ArrayList<String>> finalMap= new HashMap<Integer,  ArrayList<String>>();
		
		for(ArrayList<String> al: Actual)
		{
			actMap.put(al.get(0), al.get(1));
		}

		for(ArrayList<String> el: Expected)
		{
			if(el.get(0).contains("_Name"))
			{
				exptMap.put(el.get(0).replace("//CREDIT_SUMMARY[1]/_DATA_SET[", "").replace("]@_Name", ""), el.get(1));
			}
		}

		int MatchedCount=0;
		int UnMatchedCount=0;
		for(String key:actMap.keySet())
		{
			 ArrayList<String> al=new  ArrayList<String>();
			 
			if(! actMap.isEmpty() || exptMap.isEmpty())
			{
				if(actMap.get(key).equals(exptMap.get(key)))
				{
					al.add(actMap.get(key));
					al.add(exptMap.get(key));
					finalMap.put(Integer.parseInt(key), al);
					++MatchedCount;
				}
				else
				{
					++UnMatchedCount;
				}
			}
		}

		String[] m2xTagPositionReport = GenerateReport.M2XTagPositionReport(finalMap, path, "M2XTagPositionVerification");
		if(m2xTagPositionReport[0].equalsIgnoreCase("success"))
		{
			result.add(m2xTagPositionReport[1].replace("\\", "/"));
			result.add(String.valueOf(MatchedCount));
			result.add(String.valueOf(UnMatchedCount));
			
		}
		return result;		
	}

}
