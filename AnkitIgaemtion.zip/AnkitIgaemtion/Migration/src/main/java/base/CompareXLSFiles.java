package base;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class CompareXLSFiles{

	public static void xmlCompare(String folderName, String subFolderName) {
		ArrayList<ArrayList<String>> File1=ReadFromExcelFile.getCellValue("OutputFiles"+File.separator+folderName+File.separator+subFolderName+File.separator+"_MISMO_1X_Request_Attribute_Verification.xlsx");
		ArrayList<ArrayList<String>> File2=ReadFromExcelFile.getCellValue("OutputFiles"+File.separator+folderName+File.separator+subFolderName+File.separator+"_MISMO_2X_Request_Attribute_Verification.xlsx");
		
		Map<String, String> File1Mapping=new HashMap<String, String>();
		
		for(ArrayList<String> f1: File1)
		{
			String Tagname=f1.get(0);
			String Value=f1.get(1);
			File1Mapping.put(Tagname, Value);
		}
		
		Map<String, String> File2Mapping=new HashMap<String, String>();
		for(ArrayList<String> f2: File2)
		{
			String Tagname=f2.get(0);
			String Value=f2.get(1);
			File2Mapping.put(Tagname, Value);
		}
		Map<String, String> MaxMap=new HashMap<String, String>();
		Map<String, String> MinMap=new HashMap<String, String>();
		if(File2Mapping.size()>File1Mapping.size())
		{
			MaxMap= File2Mapping;
			MinMap= File1Mapping;
		}
		else
		{
			MaxMap= File1Mapping;
			MinMap= File2Mapping;
		}
		ArrayList<ArrayList<String>> result=new ArrayList<ArrayList<String>>();
		Iterator<Map.Entry<String, String>> maxI = MaxMap.entrySet().iterator();

			while(maxI.hasNext())
			{
				Entry<String, String> next1 = maxI.next();
				ArrayList<String> templist=new ArrayList<String>();
				
				Iterator<Map.Entry<String, String>> minI = MinMap.entrySet().iterator();
				Boolean status=true;
				MinMap=new HashMap<String, String>();
				while(minI.hasNext())
				{
					Entry<String, String> next2 = minI.next();
					if(next1.getValue().equals(next2.getValue()) && status)
					{
						templist.add(next2.getValue());
						templist.add(next1.getKey());
						templist.add(next2.getKey());
						minI.remove();
						status=false;
					}
					else
					{
						MinMap.put(next2.getKey(), next2.getValue());
					}
					
				}
				if(!templist.isEmpty())
				{
					result.add(templist);
				}
		}
			GenerateReport.XMLOutputinExcel(result, folderName, subFolderName,"Compare","test");
	}
}
