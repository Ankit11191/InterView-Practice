package base;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;

public class WriteIntoFile extends logging {
	
	public String fileName1=ReadProerties.propsObjectsSplit("TemplateName")+new  SimpleDateFormat("yyyy_MM_dd").format(new Date());
	
	public List<String> write(String requestString, byte[] responseString, String requestFileName,String responseFileName, String fileType, 
			String folderName, String OuterfolderName)
	{
		String[] requestResult=requestFileName.split("_");
		String[] responseResult=responseFileName.split("_");
	String folderStructure1=System.getProperty("user.dir") + File.separator + "Result"+File.separator+folderName;	
	String requestStructure=System.getProperty("user.dir") + File.separator + "Result"+File.separator+folderName+File.separator+requestResult[0];
	String responseStructure=System.getProperty("user.dir") + File.separator + "Result"+File.separator+folderName+File.separator+responseResult[0];
				File makdir1 = new File(folderStructure1);
				File makdir2 = new File(requestStructure);
				File makdir3 = new File(responseStructure);
				if (!makdir2.exists()) {
					makdir1.mkdir();
					makdir2.mkdir();
					makdir3.mkdir();
				}
				
				requestFileName = requestFileName.replace("Requests_", "");
				
				String requestOutPutFileName = requestStructure + File.separator+ requestFileName+".xml";
				logger.info(requestResult[0]+" File is available at :" +requestOutPutFileName);

				try (BufferedWriter bw = new BufferedWriter(new FileWriter(requestOutPutFileName))) {
					bw.write(requestString);
				} catch (IOException e) {
					e.printStackTrace();
				}
		

				responseFileName = responseFileName.replace("Response_", "");
				String responseOutPutFileName = responseStructure + File.separator+ responseFileName+"."+fileType;
				logger.info(responseResult[0]+" File is available at : "+ responseOutPutFileName);
				
					OutputStream out;
					try {
						out = new FileOutputStream(responseOutPutFileName);
						out.write(Base64.getDecoder().decode(responseString));
						out.close();
					} catch (Exception e) {
						e.printStackTrace();
					}
				
				List<String> result=new ArrayList<String>();
				requestOutPutFileName=OuterfolderName+File.separator+requestResult[0]+File.separator+ requestFileName+".xml";
				responseOutPutFileName=OuterfolderName+File.separator+responseResult[0]+File.separator+responseFileName+"."+fileType;
				
				result.add(requestOutPutFileName);
				result.add(responseOutPutFileName);
			
		return result;
	}

	
	public List<String> write(String requestString, String responseString, String requestFileName,String responseFileName, String fileType, String folderName, String OuterfolderName)
	{
		String[] requestResult=requestFileName.split("_");
		String[] responseResult=responseFileName.split("_");
	String folderStructure1=System.getProperty("user.dir") + File.separator + "Result"+File.separator+folderName;	
	String requestStructure=System.getProperty("user.dir") + File.separator + "Result"+File.separator+folderName+File.separator+requestResult[0];
	String responseStructure=System.getProperty("user.dir") + File.separator + "Result"+File.separator+folderName+File.separator+responseResult[0];
				File makdir1 = new File(folderStructure1);
				File makdir2 = new File(requestStructure);
				File makdir3 = new File(responseStructure);
				if (!makdir2.exists()) {
					makdir1.mkdir();
					makdir2.mkdir();
					makdir3.mkdir();
				}
				
				requestFileName = requestFileName.replace("Request_", "");
				
				String requestOutPutFileName = requestStructure + File.separator+ requestFileName+".xml";
				logger.info(requestResult[0]+" File is available at :" +requestOutPutFileName);

				try (BufferedWriter bw = new BufferedWriter(new FileWriter(requestOutPutFileName))) {
					bw.write(requestString);
				} catch (IOException e) {
					e.printStackTrace();
				}
		

				responseFileName = responseFileName.replace("Response_", "");
				String responseOutPutFileName = responseStructure + File.separator+ responseFileName+"."+fileType;
				logger.info(responseResult[0]+" File is available at : "+ responseOutPutFileName);
				
					try (BufferedWriter bw = new BufferedWriter(new FileWriter(responseOutPutFileName))) {
						bw.write(responseString);
					} catch (IOException e) {
						e.printStackTrace();
					}

				List<String> result=new ArrayList<String>();
				requestOutPutFileName=OuterfolderName+File.separator+requestResult[0]+File.separator+ requestFileName+".xml";
				responseOutPutFileName=OuterfolderName+File.separator+responseResult[0]+File.separator+responseFileName+"."+fileType;
				
				result.add(requestOutPutFileName);
				result.add(responseOutPutFileName);
			
		return result;
	}
	
}