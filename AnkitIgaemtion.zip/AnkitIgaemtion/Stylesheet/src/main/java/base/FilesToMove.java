package base;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;

public class FilesToMove {
	
	public static void moveTo(String path)
	{
		String source = System.getProperty("user.dir") + File.separator + path;
		File srcDir = new File(source);

		String newFolderName=new  SimpleDateFormat("yyyy_MM_dd_hh_mm_ss").format(new Date());
		File makdir = new File(System.getProperty("user.dir") + File.separator + path+File.separator +newFolderName);
		if (!makdir.exists()) {
			makdir.mkdir();
		}
		String destination = System.getProperty("user.dir") + File.separator + path +File.separator +newFolderName;
		File destDir = new File(destination);

		try {
		    FileUtils.moveDirectory(srcDir, destDir);
		} catch (IOException e) {
		    e.printStackTrace();
		}
	}
}
