package base;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Hyperlink;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import call.Calling;

public class GenerateReport extends logging {
	@SuppressWarnings("resource")
	public static void ResultInExcel(ArrayList<ArrayList<String>> data, String FolderName) {

		Workbook workbook = new XSSFWorkbook();
		Sheet sheet = workbook.createSheet(ReadProerties.propsObjectsSplit("TemplateName"));
		sheet.protectSheet("");

		Font headerFont = workbook.createFont();
		headerFont.setBold(true);
		headerFont.setFontHeightInPoints((short) 13);
		headerFont.setColor(IndexedColors.BLUE.getIndex());

		CreationHelper createHelper = workbook.getCreationHelper();

		CellStyle headerCellStyle = workbook.createCellStyle();
		headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
		headerCellStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
		headerCellStyle.setBorderBottom(CellStyle.BORDER_THIN);
		headerCellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
		headerCellStyle.setBorderLeft(CellStyle.BORDER_THIN);
		headerCellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
		headerCellStyle.setBorderRight(CellStyle.BORDER_THIN);
		headerCellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
		headerCellStyle.setBorderTop(CellStyle.BORDER_THIN);
		headerCellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
		headerCellStyle.setFont(headerFont);
		Row headerRow = sheet.createRow(0);
		String[] columns = { "S.No.", "OrderNumber", "XSL_IDENTIFIER", "OUTPUT_TYPE", "RequestFileName",
				"ResponseFileName", "Status Code", "Status" };
		for (int i = 0; i < columns.length; i++) {
			Cell cell = (Cell) headerRow.createCell(i);
			cell.setCellValue(columns[i]);
			cell.setCellStyle(headerCellStyle);
		}

		int rowNum = 1;
		for (ArrayList<String> rowData : data) {
			Font fontColur = workbook.createFont();
			CellStyle cellStyle = workbook.createCellStyle();
			cellStyle.setBorderBottom(CellStyle.BORDER_THIN);
			cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
			cellStyle.setBorderLeft(CellStyle.BORDER_THIN);
			cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
			cellStyle.setBorderRight(CellStyle.BORDER_THIN);
			cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
			cellStyle.setBorderTop(CellStyle.BORDER_THIN);
			cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
			cellStyle.setLocked(true);
			int cellNum = 0;

			Row row = sheet.createRow(rowNum++);
			Cell cell = null;
			cell = row.createCell(cellNum++);
			fontColur.setColor(IndexedColors.DARK_TEAL.getIndex());
			cellStyle.setFont(fontColur);
			cell.setCellValue(rowNum - 1);
			cell.setCellStyle(cellStyle);

			for (String cellData : rowData) {
				cell = row.createCell(cellNum++);
				if (cellData == "Fail") {
					fontColur.setColor(IndexedColors.RED.getIndex());
					cellStyle.setFont(fontColur);
					cell.setCellValue(cellData);
					if (cellNum == 5 || cellNum == 6) {
						Hyperlink link = (Hyperlink) createHelper.createHyperlink(Hyperlink.LINK_URL);
						link.setAddress(cellData);
						cell.setHyperlink((Hyperlink) link);
					}
				} else {

					fontColur.setColor(IndexedColors.DARK_TEAL.getIndex());
					cellStyle.setFont(fontColur);
					cell.setCellValue(cellData);

					if (cellNum == 5 || cellNum == 6) {
						Hyperlink link = (Hyperlink) createHelper.createHyperlink(Hyperlink.LINK_FILE);
						link.setAddress(cellData);
						cell.setHyperlink((Hyperlink) link);
					}
				}
				cell.setCellStyle(cellStyle);
			}
		}
		for (int i = 0; i < columns.length; i++) {
			sheet.autoSizeColumn(i);
		}

		FileOutputStream fileOut = null;
		try {
			fileOut = new FileOutputStream(System.getProperty("user.dir") + File.separator + "Result" + File.separator
					+ Calling.format + File.separator + ReadProerties.propsObjectsSplit("TemplateName") + ".xlsx");

			workbook.write(fileOut);
			fileOut.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info("Report is successfully Generated at location :" + System.getProperty("user.dir") + File.separator
				+ "Result" + File.separator + FolderName + File.separator
				+ ReadProerties.propsObjectsSplit("TemplateName") + ".xlsx");

	}
}