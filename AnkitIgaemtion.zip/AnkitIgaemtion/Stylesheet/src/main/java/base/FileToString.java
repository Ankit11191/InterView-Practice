package base;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class FileToString extends logging {

	public static String textToString(String TemplateName) {
		File file = null;
		if (TemplateName.equalsIgnoreCase("pdf")) {
			file = new File(System.getProperty("user.dir") + File.separator + "Templates" + File.separator
					+ ReadProerties.propsObjectsSplit("E0XMLTemplateName")
					+ ReadProerties.propsObjectsSplit("E0XMLTemplateType"));
		}
		else if (TemplateName.equalsIgnoreCase("RGXJson")) {
			file = new File(System.getProperty("user.dir") + File.separator + "Templates" + File.separator
					+ ReadProerties.propsObjectsSplit("RGXTemplateName")
					+ ReadProerties.propsObjectsSplit("RGXTemplateType"));
		}else {
			file = new File(System.getProperty("user.dir") + File.separator + "Templates" + File.separator
					+ ReadProerties.propsObjectsSplit("TemplateName")
					+ ReadProerties.propsObjectsSplit("TemplateType"));
		}
		String line = "";
		StringBuilder oldtext = new StringBuilder();
		BufferedReader reader = null;

		try {
			reader = new BufferedReader(new FileReader(file));
			while ((line = reader.readLine()) != null) {
				oldtext.append(line + "\r\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return oldtext.toString();
	}
}