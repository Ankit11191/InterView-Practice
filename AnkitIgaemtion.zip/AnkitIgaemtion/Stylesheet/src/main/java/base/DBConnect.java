package base;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DBConnect {

	static Connection conn = null;

	public static List<Map<Object, Object>> callDB(String query) throws SQLException {

		String URL = "jdbc:oracle:thin:@172.21.51.29:1521/";
		String Uname = "akm11";
		String Pass = "GameChanger@2018";
		String DBname = "emstest";
		Object keys = null;
		Object values = null;
		Map<Object, Object> hashMap = new HashMap<Object, Object>();
		List<Map<Object, Object>> list = new ArrayList<Map<Object, Object>>();

		ResultSet rs = null;
		ResultSetMetaData rsMD;
		Statement stmt = null;

		try {
			Class.forName("oracle.jdbc.OracleDriver");
			System.out.println("Connecting to database...");
			conn = DriverManager.getConnection(URL + DBname, Uname, Pass);
			System.out.println("conn open");
			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);//
			rs = stmt.executeQuery(query);
			rsMD = rs.getMetaData();

			int Columncount = rsMD.getColumnCount();
			int rowcount = 0;

			while (rs.next()) {
				rowcount++;
			}
			
			System.out.println("Total Number Of Columns: " + Columncount);
			System.out.println("Total Number Of Rows: " + rowcount);
			rs.beforeFirst();
			
			for (int i = 1; i <= rowcount; i++) {
				if (rs.next()) {
					for (int j = 1; j <= Columncount; j++) {
						keys = rsMD.getColumnName(j);
						values = rs.getString(j);
						hashMap.put(keys, values);
					}
				}
				list.add(hashMap);
			}
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			conn.close();
			stmt.close();
			rs.close();
			if (conn != null)
				conn.close();
			System.out.println(".....  conn has closed.........");
		}
		return list;
	}

	public static void main(String[] args) throws SQLException {
		String q = "select * from CUSTOMEREVENT where ORDERNO in('J3S0A5',	'J3S0B0',	'J3S088',	'J3S082',	'J3S0A5',	'J3S0B0',	'J3S0G3',	'J3S0G4',	'J3S088',	'J3S0G3')";

		List<Map<Object, Object>> abc =(callDB(q));
		for (Map<Object, Object> map : abc) {
		for (Map.Entry<Object, Object> ankit : map.entrySet()) {
			System.out.println(ankit.getKey() + " - " + ankit.getValue());
		}
		System.out.println();
		}
	}
}