package base;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

public class PDFVerification {

	public static byte[] PDFXMLResponse(String RequestString, String OrderNumber, String XSL_IDENTIFIER, String OUTPUT_TYPE) {
		
		String responseJSON = CallWebService.E0XMLResponse(RequestString);
		responseJSON=responseJSON.replace("<?xml version=\"1.0\"?>", "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>");
		
		String RGXxmlrequest = FileToString.textToString("RGXJson");
		responseJSON = responseJSON.replace("\"", "\\\\\"");
		String responseJSONvalue = responseJSON.replaceAll("[\\t\\n\\r]+", "");
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("OrderNumber", OrderNumber);
		map.put("XSL_IDENTIFIER", XSL_IDENTIFIER);
		map.put("OUTPUT_TYPE", OUTPUT_TYPE);
		map.put("responseJSON", responseJSONvalue);
		
		String patternString = "\\$\\{(" + StringUtils.join(map.keySet(), "|") + ")\\}";
		Pattern pattern = Pattern.compile(patternString);
		Matcher matcher = pattern.matcher(RGXxmlrequest);
		StringBuffer pdfRequestString = new StringBuffer();

		System.out.println(map.get("OrderNumber")+" - "+map.get("XSL_IDENTIFIER")+" - "+map.get("responseJSON")+" - "+map.get("OUTPUT_TYPE")+" - ");
		
		System.out.println(matcher.toString());
		
		while (matcher.find()) {
			matcher.appendReplacement(pdfRequestString, map.get(matcher.group(1)));
		}
		matcher.appendTail(pdfRequestString);
		String JsonResponce = CallWebService.RGXResponse(pdfRequestString.toString());
		byte[] responceinBytes = null;
		if(JsonResponce.startsWith("Response is failed with error code :"))
		{
//			responceinBytes = JsonResponce.getBytes(StandardCharsets.UTF_8);
		}
		else
		{
			responceinBytes = JsonResponce.getBytes(StandardCharsets.UTF_8);
		}
		return responceinBytes;		
		
	}
}
