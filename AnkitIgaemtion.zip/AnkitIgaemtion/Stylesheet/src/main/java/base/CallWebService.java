package base;

import java.util.ArrayList;
import java.util.List;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class CallWebService {

	private static String protocallType = ReadProerties.propsObjectsSplit("protocallType") + "://";
	private static String envName = ReadProerties.propsObjectsSplit("envName");
	private static String wsPAth = ReadProerties.propsObjectsSplit("wsPAth");
	private static String RGXenvName = ReadProerties.propsObjectsSplit("RGXwsPath");

	private static Response postAPI(String RequestString) {
		return RestAssured.given().contentType("application/xml").body(RequestString).when()
				.post(protocallType + envName + wsPAth);
	}

	private static String RGXpostAPI(String pdfRequestString) {
		try {
			Response response = RestAssured.given().contentType("text/plain").body(pdfRequestString).when()
					.post(protocallType + RGXenvName);
			if (response.statusCode() == 200) {
				return response.then().statusCode(200).extract().path("response");
			} else {
				return "Response is failed with error code : " + response.statusCode() + " Please recheck request";
			}

		} catch (Exception err) {
			return err.getLocalizedMessage();
		}
	}

	@SuppressWarnings("unused")
	private static Response getAPI() {
		return RestAssured.given().get(protocallType + envName + wsPAth);
	}

	@SuppressWarnings("unused")
	private static Response putAPI(String RequestString) {
		return RestAssured.given().contentType("application/xml").body(RequestString).when()
				.get(protocallType + envName + wsPAth);
	}

	@SuppressWarnings("unused")
	private static Response deleteAPI(String RequestString) {
		return RestAssured.given().delete(protocallType + envName + wsPAth);
	}

	public static String E0XMLResponse(String E0XMLRequestString) {
		Response response = postAPI(E0XMLRequestString);
		return response.getBody().asString();
	}

	public static String RGXResponse(String pdfRequestString) {
		return RGXpostAPI(pdfRequestString);
	}

	public static ArrayList<String> response(String RequestString, String RequestFileName, String ResponseFileName,
			String FileType, String FolderName, String OuterfolderName) {
		Response response = null;
		response = postAPI(RequestString);

		WriteIntoFile writeIntoFile = new WriteIntoFile();
		ArrayList<String> result = new ArrayList<String>();
		response.time();
		if (response.statusCode() == 200) {
			List<String> resultTemp = writeIntoFile.write(RequestString, response.getBody().asString(), RequestFileName,
					ResponseFileName, FileType, FolderName, OuterfolderName);
			for (String value : resultTemp) {
				value = value.replace("\\", "/");
				result.add(value);
				result.add(String.valueOf(response.time()));
			}
			result.add(String.valueOf(response.statusCode()));
			if (response.statusCode() == 200) {
				result.add("Success");
				result.add(String.valueOf(response.time()));
			}
			return result;
		}

		else {
			List<String> resultTemp = writeIntoFile.write(RequestString, response.getBody().asString(), RequestFileName,
					ResponseFileName, FileType, FolderName, OuterfolderName);
			for (String value : resultTemp) {
				value = value.replace("\\", "/");
				result.add(value);
				result.add(String.valueOf(response.time()));
			}
			result.add(String.valueOf(response.statusCode()));
			if (response.statusCode() == 200) {
				result.add("Failed");
				result.add(String.valueOf(response.time()));
			}
			return result;
		}
	}
}
