package call;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import base.CallWebService;
import base.ColumnWiseRead;
import base.FileToString;
import base.GenerateReport;
import base.PDFVerification;
import base.ReadProerties;
import base.WriteIntoFile;
import base.logging;

public class Calling extends logging {
	public static String format = "Style_Sheet_"+new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss").format(new Date());
	public static String format1 = "Style_Sheet_2018_05_16_14_55_04";
	
	public static void main(String[] args) {
		ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();
		String folderName = null;

		try
		{
		logger.info(
				"==============================================================================================================================================");
		logger.info(format+"_" + ReadProerties.propsObjectsSplit("TestingType") + "_TESTING_START");
		
		Map<String, ArrayList<String>> tokens = ColumnWiseRead.columnWiseCalling("FileName");

		Map<String, String> token = new HashMap<>();
		int arrayListSize = 0;

		for (Map.Entry<String, ArrayList<String>> arrayCount : tokens.entrySet()) {
			arrayListSize = arrayCount.getValue().size();
		}

		int count = 0;
		for (int itrNo = 0; itrNo < arrayListSize; itrNo++) {
			for (Map.Entry<String, ArrayList<String>> ankit : tokens.entrySet()) {
				token.put(ankit.getKey(), ankit.getValue().get(itrNo));
			}
			
			if (token.get("ACTIVE").equalsIgnoreCase("Y")) {
				ArrayList<String> responseValue = new ArrayList<>();

				String xmlrequest = FileToString.textToString("notpdf");
				String patternString = "\\$\\{(" + StringUtils.join(token.keySet(), "|") + ")\\}";
				Pattern pattern = Pattern.compile(patternString);
				Matcher matcher = pattern.matcher(xmlrequest);

				StringBuffer requestString = new StringBuffer();
				while (matcher.find()) {
					matcher.appendReplacement(requestString, token.get(matcher.group(1)));
				}
				matcher.appendTail(requestString);
				String folderStructure1=System.getProperty("user.dir") + File.separator + "Result"+File.separator+format;
				File makdir1 = new File(folderStructure1);
				if(!makdir1.exists())
				{
					makdir1.mkdir();
				}
				folderName=format+File.separator+token.get("StyleSheetType");
				if (token.get("FileOutputFormat").equalsIgnoreCase("pdf")) {

					String E0XMLrequest = FileToString.textToString("pdf");

					String patternStringPDF = "\\$\\{(" + StringUtils.join(token.keySet(), "|") + ")\\}";
					Pattern patternPDF = Pattern.compile(patternStringPDF);
					Matcher matcherPDF = patternPDF.matcher(E0XMLrequest);

					StringBuffer requestStringPDF = new StringBuffer();
					while (matcherPDF.find()) {
						matcherPDF.appendReplacement(requestStringPDF, token.get(matcherPDF.group(1)));
					}
					matcher.appendTail(requestStringPDF);
					byte[] PDFinBytes = PDFVerification.PDFXMLResponse(requestStringPDF.toString(),
							token.get("OrderNumber"), token.get("XSL_IDENTIFIER"), token.get("OUTPUT_TYPE"));

					
					WriteIntoFile writeIntoFile = new WriteIntoFile();

					List<String> PDFresponseValue = writeIntoFile.write(requestString.toString(), PDFinBytes,
							token.get("RequestFileName"), token.get("ResponseFileName"), token.get("FileOutputFormat"),
							folderName, token.get("StyleSheetType"));

					for (String value : PDFresponseValue) {
						value = value.replace("\\", "/");
						responseValue.add(value);
					}
					responseValue.add("200");
					responseValue.add("Success");

				} else {
					responseValue = CallWebService.response(requestString.toString(), token.get("RequestFileName"),
							token.get("ResponseFileName"), token.get("FileOutputFormat"), folderName, token.get("StyleSheetType"));
				}
				ArrayList<String> list = new ArrayList<String>();

				list.add(token.get("OrderNumber"));
				list.add(token.get("RequestFileName"));
				list.add(token.get("ResponseFileName"));
				list.addAll(responseValue);
				++count;
				data.add(list);
				logger.info(
						"==============================================================================================================================================");
			}
			
		}
			logger.info("Done with total " + count + " requests at " + format);
		}
		finally
		{
			GenerateReport.ResultInExcel(data, folderName);
		}
		logger.info(
				"==============================================================================================================================================");
	}

}
