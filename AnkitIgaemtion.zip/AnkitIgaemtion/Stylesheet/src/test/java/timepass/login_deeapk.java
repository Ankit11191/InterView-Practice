package timepass;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

public class login_deeapk {
	   @SuppressWarnings("unused")
	private static String updateRequest(String inq, String fileName, String env) {
	        int fmSegmentIdx = inq.indexOf("BGN*00*FM");
	        StringBuffer buf = new StringBuffer();
	        buf.append(inq.substring(0, fmSegmentIdx + 7));
	        buf.append(fileName);
	        buf.append(inq.substring(fmSegmentIdx + 21, fmSegmentIdx + 31));
	        System.out.println("ENVIRONMENT - " + env);

	        if (env.equalsIgnoreCase("production")) {
	            buf.append("17202111604003100");
	            System.out.println("IP Address appended = 17202111604003100");
	        } else {
	            buf.append("17202111224803100");
	            System.out.println("IP Address appended = 17202111224803100");
	        }
	        buf.append(inq.substring(fmSegmentIdx + 48, inq.length()));
	        System.out.println(buf.toString());
	        return buf.toString();
	    }

	    @SuppressWarnings("unused")
		private static String getFileName(String inq) {
	        String responseFileName = null;
	        if (inq != null && inq.indexOf("BGN*00*FM") > 0) {
	            int fmSegmentIdx = inq.indexOf("BGN*00*FM");
	            responseFileName = inq.substring(fmSegmentIdx + 7,
	                                             fmSegmentIdx + 7 + 20);
	            responseFileName = responseFileName.replace(' ', '_');
	        }
	        return responseFileName;
	    }
	    
	    private static void sendData(OutputStreamWriter os, String data) {
	        try {
	            os.write(data);
	            os.write("\n");
	            os.flush();
	        } catch (Exception e) {
	            System.out.println("Error writing fMAC " + e);
	            e.printStackTrace();
	        }
	    }
	    
	    private static StringBuffer readAck(InputStreamReader serverSocketReader) {

	        BufferedReader socketReader = new BufferedReader(serverSocketReader);
	        StringBuffer strResp = new StringBuffer();
	        String temp = "";
	        try {

	            while ((temp = socketReader.readLine()) != null) {

	                if (temp.contains("ORDER*ERROR:")) {
	                    strResp.append("NACK : " + temp);

	                } else if (temp.contains("ORDER")) {

	                    strResp.append("ACK  : " + temp);
	                }
	            }

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return strResp;
	    }
	    
	public static void main(String[] args) {
				String inputReq = FileToReading.textToString("req.txt");
				Socket socket = null;
			    InputStreamReader is = null;
			    OutputStreamWriter os = null;

			    StringBuffer result = new StringBuffer(20000);

			    String inq = inputReq.replace("\n", "\r");

/*			    String fmSegment = "FM" + new SimpleDateFormat("ddHHmmssSSS").format(new Date()) + "M";
			    String env = "QA";
			    String request = updateRequest(inq, fmSegment, env);
			    String fileName = getFileName(inputReq);
			    int iPort = 8105;
			    String uri = "mortqc2.fin.equifax.com";*/
			    try {
			        socket = new Socket("mortqc2.fin.equifax.com", 8105);
			        is = new InputStreamReader(socket.getInputStream());
			        os = new OutputStreamWriter(socket.getOutputStream());
			        socket.setSoTimeout(60000);

			       // StringBuffer temp = null;

			        sendData(os, inq);

			        StringBuffer ack = readAck(is);
			        //int ackLength = StringUtils.trimToEmpty(ack.toString()).length();

			        result.append(ack);
			        result.append("\n\n");
			        /*if (ack.indexOf("NACK") > -1 || ackLength <= 92) {
			            System.out.println(result.toString());
			        } else {

			            String fileResult = readLinuxFile(fileName);

			            result.append(fileResult);
			        }*/

			    } catch (Exception e) {
			        e.printStackTrace();
			    } finally {
			        try {
			            if (socket != null) {
			                socket.close();
			            }
			        } catch (IOException e) {
			        }
			    }
			    System.out.println("Result :: " + result.toString());

		}
}
