package timepass;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

public class Socketconnection {

	public static void main(String[] args) {
		String inputReq = FileToReading.textToString("req.txt");
		Socket socket = null;
	    InputStreamReader is = null;
	    OutputStreamWriter os = null;

	    StringBuffer result = new StringBuffer(20000);

	    String inq = inputReq.replace("\n", "\r");
	    try {
	        socket = new Socket("mortqc2.fin.equifax.com", 8105);
	        os = new OutputStreamWriter(socket.getOutputStream());
	        is = new InputStreamReader(socket.getInputStream());
	        socket.setSoTimeout(60000);
	        
	        os.write(inq);
            os.write("\n");
            os.flush();
            
	        StringBuffer ack = readAck(is);
	        result.append(ack);
	        result.append("\n\n");
	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if (socket != null) {
	                socket.close();
	            }
	        } catch (IOException e) {
	        }
	    }
	    if(!result.toString().contains("ORDER*ERROR:"))
	    {
	    	System.out.println(result.toString().substring(79, 86));
	    }
	    else
	    {
	    	System.out.println(result.toString());
	    }
	}
    private static StringBuffer readAck(InputStreamReader serverSocketReader) {

        BufferedReader socketReader = new BufferedReader(serverSocketReader);
        StringBuffer strResp = new StringBuffer();
        String temp = "";
            try {
				while ((temp = socketReader.readLine()) != null) {
						strResp.append(temp);
				    }
			} catch (IOException e) {
				e.printStackTrace();
			}
        return strResp;
    }
}
