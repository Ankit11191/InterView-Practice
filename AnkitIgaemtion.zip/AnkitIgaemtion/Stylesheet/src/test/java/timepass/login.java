package timepass;

public class login {
	public static void main(String[] args) {
		/*static String readLinuxFile( String fileToBeRead) throws IOException {
	        System.out.println(System.getProperty("os.name"))
	        String hostname = "172.21.112.248"
	        String username = ""
	        String password = ""

	        JSch jsch = new JSch()
	        Session session = null
	        String result = null
	        System.out.println("Trying to connect.....")
	        try {

	            session = jsch.getSession(username, hostname, 22)
	            session.setConfig("StrictHostKeyChecking", "no")
	            session.setPassword(password)
	            session.setConfig(
	                    "PreferredAuthentications",
	                    "publickey,keyboard-interactive,password")
	            session.connect()
	            Channel channel = session.openChannel("sftp")
	            channel.connect()
	            ChannelSftp sftpChannel = (ChannelSftp) channel



	            InputStream in1 = sftpChannel.get("/export/home/mortapp/QA/fmac_out/" + fileToBeRead)



	            FileOutputStream out = new FileOutputStream("../mortgage-test-assist-extension/src/main/resources/Responses/TempPartialFMAC" + "_" + "_Response" + "_" + fileToBeRead)

	            byte[] mb = new byte[1024]
	            for (int c = in1.read(mb, 0, 1024); c > 0; c = in1.read(mb, 0, 1024)) {
	                out.write(mb, 0, 1024)
	            }
	            out.close()



	            result = FileUtils.readFileToString(new File(
	                    "../mortgage-test-assist-extension/src/main/resources/Responses/TempPartialFMAC" + "_" + "_Response" + "_" + fileToBeRead), "UTF-8")
	            //   sock.close();

	            sftpChannel.exit()
	            session.disconnect()
	        } catch (JSchException e) {
	            e.printStackTrace()
	        } catch (SftpException e) {
	            e.printStackTrace()
	        }
	        System.out.println("Done !!")
	        return result
	    }
	}*/
	}
}
